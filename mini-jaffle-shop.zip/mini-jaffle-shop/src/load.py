"""PostgreSQL loading utilities for Mini Jaffle Shop."""

import os
from collections.abc import Iterable

import pandas as pd
import psycopg
from dotenv import load_dotenv


def get_connection():
    """Open a PostgreSQL connection using PG* environment variables."""
    load_dotenv()
    required = ["PGHOST", "PGDATABASE", "PGUSER", "PGPASSWORD"]
    missing = [key for key in required if not os.getenv(key)]
    if missing:
        raise RuntimeError(
            "Missing PostgreSQL settings: " + ", ".join(missing)
            + ". Copy .env.example to .env and configure it."
        )

    return psycopg.connect(
        host=os.environ["PGHOST"],
        port=os.getenv("PGPORT", "5432"),
        dbname=os.environ["PGDATABASE"],
        user=os.environ["PGUSER"],
        password=os.environ["PGPASSWORD"],
    )


def load_orders(frame: pd.DataFrame, table: str = "stg_orders") -> int:
    """Insert transformed orders into an existing staging table.

    The destination table must already exist. The table name is restricted
    to a simple SQL identifier to avoid unsafe dynamic SQL.
    """
    if not table.replace("_", "").isalnum() or table[0].isdigit():
        raise ValueError("Invalid table name")

    rows: Iterable[tuple] = (
        (
            int(row.order_id),
            int(row.customer_id),
            row.order_date,
            str(row.status),
        )
        for row in frame.itertuples(index=False)
    )

    inserted = 0
    with get_connection() as connection:
        with connection.cursor() as cursor:
            for row in rows:
                cursor.execute(
                    f"""
                    INSERT INTO {table}
                        (order_id, customer_id, order_date, status)
                    VALUES (%s, %s, %s, %s)
                    ON CONFLICT (order_id) DO UPDATE SET
                        customer_id = EXCLUDED.customer_id,
                        order_date = EXCLUDED.order_date,
                        status = EXCLUDED.status
                    """,
                    row,
                )
                inserted += 1
    return inserted

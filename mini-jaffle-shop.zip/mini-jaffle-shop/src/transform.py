"""Cleaning and validation utilities for Mini Jaffle Shop."""

import pandas as pd


REQUIRED_ORDER_COLUMNS = {"order_id", "customer_id", "order_date", "status"}


def transform_orders(frame: pd.DataFrame) -> pd.DataFrame:
    """Validate and clean an orders DataFrame.

    - Requires order_id, customer_id, order_date, and status.
    - Parses order_date as a date.
    - Drops duplicate order IDs, keeping the first record.
    - Removes rows missing required values.
    - Normalizes status text by stripping whitespace and lowercasing.
    """
    missing_columns = REQUIRED_ORDER_COLUMNS - set(frame.columns)
    if missing_columns:
        missing = ", ".join(sorted(missing_columns))
        raise ValueError(f"Missing required columns: {missing}")

    result = frame.copy()
    result["order_date"] = pd.to_datetime(
        result["order_date"], errors="coerce"
    ).dt.date
    result["status"] = result["status"].astype("string").str.strip().str.lower()

    result = result.dropna(subset=["order_id", "customer_id", "order_date", "status"])
    result = result.drop_duplicates(subset=["order_id"], keep="first")
    result = result.reset_index(drop=True)
    return result

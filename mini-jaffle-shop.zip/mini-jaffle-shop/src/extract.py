"""Input-data extraction utilities for Mini Jaffle Shop."""

from pathlib import Path
import pandas as pd


def extract_csv(path: str | Path) -> pd.DataFrame:
    """Read a CSV file and return its contents as a DataFrame.

    Raises:
        FileNotFoundError: If the CSV path does not exist.
        ValueError: If the CSV contains no columns.
    """
    csv_path = Path(path)
    if not csv_path.is_file():
        raise FileNotFoundError(f"Input CSV not found: {csv_path}")

    frame = pd.read_csv(csv_path)
    if len(frame.columns) == 0:
        raise ValueError(f"Input CSV has no columns: {csv_path}")
    return frame

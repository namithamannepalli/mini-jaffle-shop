# Mini Jaffle Shop

A compact data engineering project for processing retail order data using Python, PostgreSQL, and SQL.

## Overview

Mini Jaffle Shop demonstrates an end-to-end data pipeline that transforms raw retail data into structured, analysis-ready datasets. The project focuses on data quality, relational database design, and reproducible data processing.

**Status:** Initial project scaffold; implementation is in progress.

## Tech Stack

- Python
- PostgreSQL
- SQL
- pytest

## Planned Features

- Extract and process retail order data.
- Clean and validate records before loading.
- Store structured data in PostgreSQL.
- Analyze customer orders and sales with SQL.
- Test data transformations and validation logic.
- Add incremental loading, logging, and analytical models.

## Project Structure

```text
mini-jaffle-shop/
├── data/
│   └── raw/
├── sql/
│   ├── schema.sql
│   └── models/
├── src/
│   ├── extract.py
│   ├── transform.py
│   └── load.py
├── tests/
│   └── test_transform.py
├── .env.example
├── .gitignore
├── requirements.txt
└── README.md
```

## Getting Started

### 1. Clone the repository

```bash
git clone https://github.com/YOUR-USERNAME/mini-jaffle-shop.git
cd mini-jaffle-shop
```

Replace `YOUR-USERNAME` with your GitHub username.

### 2. Create and activate a virtual environment

```bash
python -m venv .venv
```

Windows PowerShell:
```powershell
.venv\Scripts\Activate.ps1
```

Linux/macOS:
```bash
source .venv/bin/activate
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Configure PostgreSQL

Create a PostgreSQL database, then copy `.env.example` to `.env` and fill in your local connection details. Never commit `.env` or real credentials.

### 5. Implementation status

The pipeline modules and database schema are scaffolded for the next development step. Run commands will be documented here once the pipeline is implemented and tested.

## Goals

- Build reliable Python data-processing workflows.
- Apply relational database design and SQL querying.
- Implement data validation and automated tests.
- Keep the project reproducible and easy to run.

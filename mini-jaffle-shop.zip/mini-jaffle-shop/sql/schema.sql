-- Mini Jaffle Shop staging schema.
-- Run this against your mini_jaffle_shop PostgreSQL database.

CREATE TABLE IF NOT EXISTS stg_orders (
    order_id BIGINT PRIMARY KEY,
    customer_id BIGINT NOT NULL,
    order_date DATE NOT NULL,
    status TEXT NOT NULL CHECK (length(trim(status)) > 0)
);

CREATE INDEX IF NOT EXISTS idx_stg_orders_customer_id
    ON stg_orders (customer_id);

CREATE INDEX IF NOT EXISTS idx_stg_orders_order_date
    ON stg_orders (order_date);

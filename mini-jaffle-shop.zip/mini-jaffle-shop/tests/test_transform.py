"""Tests for order transformation logic."""

import pandas as pd
import pytest

from src.transform import transform_orders


def test_transform_parses_dates_normalizes_status_and_deduplicates():
    frame = pd.DataFrame(
        [
            {"order_id": 1, "customer_id": 10, "order_date": "2026-01-02", "status": "  PAID "},
            {"order_id": 1, "customer_id": 10, "order_date": "2026-01-02", "status": "PAID"},
            {"order_id": 2, "customer_id": 11, "order_date": "2026-01-03", "status": " shipped "},
        ]
    )

    result = transform_orders(frame)

    assert len(result) == 2
    assert result.loc[0, "status"] == "paid"
    assert str(result.loc[0, "order_date"]) == "2026-01-02"
    assert result.loc[1, "status"] == "shipped"


def test_transform_drops_rows_with_invalid_dates_or_missing_values():
    frame = pd.DataFrame(
        [
            {"order_id": 1, "customer_id": 10, "order_date": "not-a-date", "status": "paid"},
            {"order_id": 2, "customer_id": None, "order_date": "2026-01-03", "status": "shipped"},
            {"order_id": 3, "customer_id": 12, "order_date": "2026-01-04", "status": "paid"},
        ]
    )

    result = transform_orders(frame)

    assert result["order_id"].tolist() == [3]


def test_transform_rejects_missing_required_columns():
    frame = pd.DataFrame([{"order_id": 1, "status": "paid"}])

    with pytest.raises(ValueError, match="Missing required columns"):
        transform_orders(frame)
